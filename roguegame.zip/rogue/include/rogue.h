#ifndef ROGUE_H
#define ROGUE_H
#include <ncurses.h>
#include <stdlib.h>
#include <time.h>
extern int MAX_HEIGHT;
extern int MAX_WIDTH;
#endif